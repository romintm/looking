import React from "react";
export const AcmeLogo = () => (
    <img src="/looking-10-5441.gif"  alt="Acme Logo" width="130" height="80" />
)
export const LocationIcon = () => (
    <img src="/location.png" alt="Location Icon" width="25" height="25" />
)
export const GenderIcon= () => (
    <img src="/gender.png" alt="Gender Icon" width="25" height="25" />
)
export const AgeIcon= () => (
    <img src="/age-group copy.png" alt="Age Icon" width="25" height="25" />
)
export const LevelIcon= () => (
    <img src="/level-up.png" alt="Level Icon" width="25" height="25" />
)
export const CancelIcon= () => (
    <img src="/Cancel.png" alt="Cancel Icon" width="20" height="20" />
)