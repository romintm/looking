import React from "react";
export const city = [
  {label: "Milan", value: "Milan"},
  {label: "turin ", value: "turin"},
  {label: "Venice", value: "venice"},
  {label: "Roma", value: "Roma"},
  {label: "Florance", value: "Florance"},
  {label: "Genova", value: "Genova"},
];
export const age = [
  {label: "18-25", value: "18-25"},
  {label: "25-30", value: "25-30"},
  {label: "30-40", value: "30-40"},
  {label: "40 above", value: "40 above"},
  
];

export const gender = [
  {label: "female", value: "female"},
  {label: "Male", value: "Male"},
 
];
export const level = [
  {label: "Beginner (A0/A1)", value: "(A0/A1)"},
  {label: "Pre Intermediate(A2)", value: "(A2)"},
  {label: "Intermediate(B1)", value: "(B1)"},
  {label: "Upper Intermediate(B2)", value: "(B2)"},
  {label: "Advanced(C1)", value: "(C1)"},
  {label: "Proficient(C2)", value: "(C2)"},
];

